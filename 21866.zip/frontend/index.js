const API = "http://localhost:3000/movielens/api";

// Αποθήκευση βαθμολογιών χρήστη στη μνήμη του browser
let myRatings = {}; // { movieId: { title, rating } }

// ─────────────────────────────────────────
// ΑΝΑΖΗΤΗΣΗ ΤΑΙΝΙΩΝ
// ─────────────────────────────────────────
async function searchMovies() {
    const keyword = document.getElementById("search-input").value.trim();
    const errorDiv = document.getElementById("search-error");
    const table = document.getElementById("search-results");
    const tbody = document.getElementById("search-results-body");

    errorDiv.textContent = "";

    if (!keyword) {
        errorDiv.textContent = "Παρακαλώ εισάγετε μια λέξη-κλειδί για αναζήτηση.";
        return;
    }

    try {
        const res = await fetch(`${API}/movies?search=${encodeURIComponent(keyword)}`);
        const data = await res.json();

        if (data.movies.length === 0) {
            errorDiv.textContent = "Δεν βρέθηκαν ταινίες με αυτή τη λέξη-κλειδί.";
            table.classList.add("hidden");
            return;
        }

        tbody.innerHTML = "";

        for (const movie of data.movies) {
            // Φέρνουμε τα ratings για να υπολογίσουμε τον μέσο όρο
            const rRes = await fetch(`${API}/ratings/${movie.movieId}`);
            const rData = await rRes.json();
            const ratings = rData.ratings;
            const avg = ratings.length > 0
                ? (ratings.reduce((s, r) => s + r.rating, 0) / ratings.length).toFixed(2)
                : "—";

            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td>${movie.title}</td>
                <td>${movie.genres}</td>
                <td>${avg} ${ratings.length > 0 ? "★" : ""}</td>
                <td>
                    <select id="rating-${movie.movieId}">
                        <option value="">—</option>
                        ${[0.5,1,1.5,2,2.5,3,3.5,4,4.5,5].map(v =>
                            `<option value="${v}">${v} ★</option>`
                        ).join("")}
                    </select>
                    <button onclick="rateMovie(${movie.movieId}, '${movie.title.replace(/'/g, "\\'")}')">
                        Αποθήκευση
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        }

        table.classList.remove("hidden");

    } catch (err) {
        errorDiv.textContent = "Σφάλμα σύνδεσης με τον server. Ελέγξτε ότι τρέχει το backend.";
    }
}

// ─────────────────────────────────────────
// ΒΑΘΜΟΛΟΓΗΣΗ ΤΑΙΝΙΑΣ
// ─────────────────────────────────────────
function rateMovie(movieId, title) {
    const select = document.getElementById(`rating-${movieId}`);
    const rating = parseFloat(select.value);

    if (!rating) {
        alert("Παρακαλώ επίλεξε βαθμολογία πρώτα.");
        return;
    }

    myRatings[movieId] = { title, rating };
    updateRatingsList();
    alert(`Αποθηκεύτηκε: "${title}" → ${rating} ★`);
}

// Ενημέρωση λίστας βαθμολογιών στο section συστάσεων
function updateRatingsList() {
    const div = document.getElementById("my-ratings-list");
    const entries = Object.entries(myRatings);
    if (entries.length === 0) {
        div.textContent = "Δεν έχεις βαθμολογήσει ακόμα καμία ταινία.";
        return;
    }
    div.innerHTML = "<strong>Οι βαθμολογίες σου:</strong><br>" +
        entries.map(([, v]) => `<span>${v.title}: ${v.rating} ★</span>`).join("");
}

// ─────────────────────────────────────────
// ΠΡΟΣΘΗΚΗ ΝΕΑΣ ΤΑΙΝΙΑΣ
// ─────────────────────────────────────────
async function addMovie() {
    const title = document.getElementById("add-title").value.trim();
    const genres = document.getElementById("add-genres").value.trim();
    const feedback = document.getElementById("add-feedback");

    feedback.textContent = "";
    feedback.className = "feedback-msg";

    if (!title || !genres) {
        feedback.textContent = "Παρακαλώ συμπλήρωσε τίτλο και είδος.";
        feedback.classList.add("error");
        return;
    }

    try {
        const res = await fetch(`${API}/movies`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ title, genres })
        });
        const data = await res.json();

        if (data.status === "success") {
            feedback.textContent = `Η ταινία προστέθηκε με ID: ${data.movieId}`;
            feedback.classList.add("success");
            document.getElementById("add-title").value = "";
            document.getElementById("add-genres").value = "";
        } else {
            feedback.textContent = "Κάτι πήγε στραβά. Δοκίμασε ξανά.";
            feedback.classList.add("error");
        }
    } catch (err) {
        feedback.textContent = "Σφάλμα σύνδεσης με τον server.";
        feedback.classList.add("error");
    }
}

// ─────────────────────────────────────────
// ΣΥΣΤΑΣΕΙΣ
// ─────────────────────────────────────────
async function getRecommendations() {
    const errorDiv = document.getElementById("rec-error");
    const table = document.getElementById("rec-results");
    const tbody = document.getElementById("rec-results-body");

    errorDiv.textContent = "";

    const entries = Object.entries(myRatings);
    if (entries.length < 2) {
        errorDiv.textContent = "Βαθμολόγησε τουλάχιστον 2 ταινίες για να λάβεις προτάσεις.";
        return;
    }

    const ratingsPayload = entries.map(([movieId, v]) => ({
        movieId: parseInt(movieId),
        rating: v.rating
    }));

    try {
        const res = await fetch(`${API}/recommendations`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ ratings: ratingsPayload })
        });
        const data = await res.json();

        if (data.recommendations.length === 0) {
            errorDiv.textContent = "Δεν βρέθηκαν προτάσεις. Δοκίμασε να βαθμολογήσεις περισσότερες ταινίες.";
            table.classList.add("hidden");
            return;
        }

        tbody.innerHTML = "";
        for (const rec of data.recommendations) {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td>${rec.title}</td>
                <td>${rec.genres}</td>
                <td>${rec.predictedRating} ★</td>
            `;
            tbody.appendChild(tr);
        }

        table.classList.remove("hidden");

    } catch (err) {
        errorDiv.textContent = "Σφάλμα σύνδεσης με τον server.";
    }
}

// Αρχικοποίηση
updateRatingsList();